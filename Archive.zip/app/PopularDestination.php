<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PopularDestination extends Model
{
    //
}
