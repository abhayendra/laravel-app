<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TourPicture extends Model
{
    //
}
