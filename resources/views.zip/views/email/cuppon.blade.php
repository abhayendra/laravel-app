<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Forgot Password | Booktours</title>
</head>

<body style="margin:0; padding:0;background:#006AC3;">
<div style="background:#006AC3; padding:15px; height:100%;">
    <div style="max-width:450px; margin:0 auto; padding:35px 15px; background:#fff; text-align:center; border-radius:10px;">
        <img src="http://www.booktours.ca/public/uploads/2018-12/8e49aa3e8b6a7209cc7e958b5664b7bb.png" alt="Book Tours"><br />
        <!--<img src="http://booktours.ca/mail_resources/coupon.png" width="150px" alt="Book Tours" style="margin:30px 0 20px 0;">-->
        <div style=" background:red; border:2px dashed yellow; color:#fff; padding:15px;font-family: sans-serif; max-width:200px; margin:30px auto 20px auto;">
            <div style="font-size:28px; font-weight:600;">10% off</div>
            <div style="font-size:18px; font-weight:600;">your entire purchase</div>
            <p style="font-size:13px; margin-top:20px;">Excluding food items.<br />
                Offer valid through June 5, 2018</p>
        </div>
        <p style="font-family: sans-serif; font-size:15px; color:#666; padding:0 20px;">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
        <a href="#" style="font-family: sans-serif;background:#006400; color:#fff; text-decoration:none; padding:12px 30px; display:inline-block; border-radius:40px; margin-top:20px;">GRAB IT</a>
    </div>
    <div style="font-family: sans-serif; color:#666; font-size:12px;max-width:450px; margin:0 auto; padding:25px 15px; background:#fff; text-align:center; margin-top:10px; border-radius:10px;">
        Copyright © 2019 BookTours.ca All rights reserved.<br />
        This e-mail was sent by BookTours.ca, Toronto Niagara Falls, Canada<br />
        <a href="#">Privacy and Cookies</a> | <a href="#">Customer service</a>
    </div>
</div>

</body>
</html>
