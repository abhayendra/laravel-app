@extends('frontend.layout.app')
@section('content')
        <!--mobile search-->
@php
$cartCollection = Cart::getContent();
@endphp

<div class="mobile_search">
    <input name="" type="text" placeholder="Search Niagara Falls"> <span id="search_hide"><i class="fa fa-times" aria-hidden="true"></i></span>
</div>
<!--end mobile search-->
<!--search-->
<div class="search_wra">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="fld_wra">
                    {!! Form::open(['url'=>'/tours/','method'=>'get']) !!}
                    <input type="text" name="search" value="" id="search-box" autocomplete="off" placeholder="Where Do You Want to Go?" class="fld1"> <button type="submit" class="btn1">Find Tours</button>
                    <div class="search_dd" id="suggesstion-box">
                    </div>
                    {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>
</div>
<!--end search-->
<!--breadcrumb-->
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <ol class="breadcrumb-my">
                <li><a href="{!! url('/') !!}">Home</a></li>
                <li><a href="{!! url('/tours') !!}">Tour</a></li>
                <li class="active">Checkout</li>
            </ol>
            <div class="clearfix"></div>
        </div>
    </div>
</div>
<!--end breadcrumb-->
<!--Popular Destinations-->
<div class="checkout_wra">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
                <h1>Checkout</h1>
                <h2>Niagara Falls Boat Tour: Voyage to the Falls
                    <span>Friday, 29 May 2015 05:50 Departures</span>
                </h2>
                <ul class="breadcrumb_checkout">
                    <li>Traveler Info</li>
                    <li class="active2">Payment Info</li>
                    <li>Completed</li>
                </ul>

                <div class="checkout_fld_wra">
                    <div class="thank">
                        THANK YOU<span>YOUR BOOKING IS COMPLETE</span>
                    </div>
                    <table width="100%" border="0" cellspacing="0" cellpadding="0" class="booking_tbl">
                        <tbody>
                        <tr>
                            <td>
                                <h3>Customer Details</h3>
                                <ul>
                                    <li><i class="fa fa-users"></i> 3 Reserved</li>
                                    <li><i class="fa fa-envelope"></i> info@info.com</li>
                                    <li><i class="fa fa-phone"></i> 9890786789</li>
                                </ul>
                            </td>
                            <td>
                                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                    <tbody>
                                    <tr>
                                        <td>Adults (2 × CA$139.00)</td>
                                        <td>CA$278.00</td>
                                    </tr>
                                    <tr>
                                        <td>Children (1 × CA$109.00)	 </td>
                                        <td>CA$109.00</td>
                                    </tr>
                                    <tr>
                                        <td>Seniors (1 × CA$129.00)</td>
                                        <td>CA$129.00</td>
                                    </tr>
                                    <tr>
                                        <td>Infants (1 × CA$0.00)</td>
                                        <td>CA$0.00</td>
                                    </tr>
                                    <tr>
                                        <td>Add-Ons </td>
                                        <td>CA$100.00</td>
                                    </tr>
                                    </tbody>
                                    <tfoot>
                                    <tr>
                                        <td>Sub Total</td>
                                        <td>CA$447.48</td>
                                    </tr>
                                    </tfoot>
                                </table>

                            </td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <h3>Add-ons Purchased</h3>
                                <table width="100%" border="0" cellspacing="0" cellpadding="0" class="booking_addon_tbl">
                                    <tbody><tr>
                                        <td>Hornblower Cruise Boat Ride</td>
                                        <td>Qty	33</td>
                                    </tr>
                                    <tr>
                                        <td>Hornblower Cruise Boat Ride - Child under 12 yrs old</td>
                                        <td>Qty	10</td>
                                    </tr>
                                    <tr>
                                        <td>Lunch Buffet	 </td>
                                        <td>Qty	19</td>
                                    </tr>
                                    <tr>
                                        <td>Lunch Dinnetr	 </td>
                                        <td>Qty	20</td>
                                    </tr>
                                    </tbody>
                                </table>

                            </td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <h3>Tour Detail</h3>
                                <table width="100%" border="0" cellspacing="0" cellpadding="0" class="booking_detail_tbl">
                                    <tbody><tr>
                                        <td>Start Date: </td>
                                        <td>2018-10-24(Wed)</td>
                                    </tr>
                                    <tr>
                                        <td>End Date:</td>
                                        <td>2018-10-25(Thu)</td>
                                    </tr>
                                    <tr>
                                        <td>Meeting Point:</td>
                                        <td>7:00am In front of the Voi Salon & Spa 253 NJ-18, East Brunswick, NJ 08816  </td>
                                    </tr>
                                    </tbody>
                                </table>

                            </td>
                        </tr>
                        </tbody>
                    </table>
                    <div class="instruction">
                        <h4>Customer Instructions</h4>
                        <ul>
                            <li><i class="fa fa-check"></i> Customer must confirm their booking and pickup address.</li>
                            <li><i class="fa fa-check"></i> Wear comfortable shoes.</li>
                            <li><i class="fa fa-check"></i> This product operates rain or shine, except in the case of extreme weather events like hurricanes.</li>
                            <li><i class="fa fa-check"></i> There is a moderate amount of walking. Niagara-on-the-Lake is an older town and is not wheelchair accessible.</li>
                            <li><i class="fa fa-check"></i> Dress weather appropriate.</li>
                            <li><i class="fa fa-check"></i> Confirmation email will be sent within 24 hours of booking this tour or activity</li>
                        </ul>
                    </div>



                </div>

            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                <div class="summary_wra">
                    <h3>Why booking with us?</h3>
                    <table width="100%" border="0" cellspacing="0" cellpadding="0" class="completed_right_tbl">
                        <tr>
                            <td><i class="fa fa-thumbs-up"></i></td>
                            <td>
                                <h5>NO BOOKING CHARGES</h5>
                                <p>We don't charge you an extra fee for booking a hotel room with us</p>
                            </td>
                        </tr>
                        <tr>
                            <td><i class="fa fa-credit-card"></i></td>
                            <td>
                                <h5>NO CANCELLATION SEES</h5>
                                <p>We don't charge you a cancellation or modification fee in case plans change</p>
                            </td>
                        </tr>
                        <tr>
                            <td><i class="fa fa-inbox"></i></td>
                            <td>
                                <h5>INSTANT CONFIRMATION</h5>
                                <p>Instant booking confirmation whether booking online or via the telephone</p>
                            </td>
                        </tr>
                        <tr>
                            <td><i class="fa fa-calendar"></i></td>
                            <td>
                                <h5>FLEXIBLE BOOKING</h5>
                                <p>You can book up to a whole year in advance or right up until the moment of your stay</p>
                            </td>
                        </tr>
                    </table>


                    <div class="risk_free">Risk free: You can cancel later, so lock in this great price today.</div>
                    <div class="demand"><span>In high demand!</span> Booked 7 times in the last 24 hours</div>
                    <div class="booking_help">Having trouble booking online?<br>
                        Call +1 (123) 456-7890</div>

                </div>
            </div>
        </div>
    </div>
</div>
<!--end Popular Destinations-->
@endsection
